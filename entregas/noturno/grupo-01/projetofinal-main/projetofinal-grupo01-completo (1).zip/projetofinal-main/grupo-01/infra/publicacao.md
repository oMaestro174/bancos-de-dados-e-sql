# Infraestrutura e Publicação — Grupo 01

Este documento explica como rodar o projeto completo localmente e traz
uma sugestão simples (opcional) de publicação online.

## Visão geral da arquitetura

```
grupo-01/
├── app/
│   ├── frontend/   -> React + Vite (interface, hoje com dados de exemplo)
│   └── backend/    -> Node.js + Express (API conectada ao MySQL)
├── sql/
│   ├── schema.sql      -> cria o banco escola_db e dados de exemplo
│   └── consultas.sql   -> consultas SQL exigidas pelo projeto
└── der/            -> diagrama entidade-relacionamento
```

## Passo a passo para rodar localmente

### 1. Banco de dados (MySQL)

```bash
mysql -u root -p < ../sql/schema.sql
```

Isso cria o banco `escola_db` com as tabelas `alunos`, `cursos`,
`turmas`, `matriculas` e `notas`, já com dados de exemplo compatíveis
com `sql/consultas.sql`.

### 2. Backend (API)

```bash
cd app/backend
npm install
cp .env.example .env   # ajuste usuário/senha do MySQL
npm start
```

A API sobe em `http://localhost:3000` (ver rotas em `app/backend/README.md`).

### 3. Front-end (interface)

```bash
cd app/frontend
npm install
npm run dev
```

A aplicação sobe em `http://localhost:5173` (endereço padrão do Vite),
já funcional com dados de exemplo (`src/data/mockData.js`).

## Ambiente usado pelo grupo

- Sistema operacional: Windows/Linux/macOS (qualquer um, o projeto usa
  apenas Node.js e MySQL, que são multiplataforma).
- Node.js: versão 18 ou superior.
- MySQL: versão 8.x local, via MySQL Workbench, XAMPP ou linha de comando.
- Editor: VS Code.

## Publicação online (opcional)

Como recurso opcional do projeto, a aplicação pode ser publicada com
serviços gratuitos, por exemplo:

- **Front-end**: Vercel ou Netlify (basta conectar o repositório e
  apontar para a pasta `app/frontend`, comando de build `npm run build`).
- **Backend**: Render ou Railway (subir a pasta `app/backend`, definindo
  as variáveis de ambiente do `.env` no painel do serviço).
- **Banco de dados**: Railway, Clever Cloud ou PlanetScale oferecem MySQL
  gratuito na nuvem; basta importar `sql/schema.sql` no banco criado.

Se a publicação online não for feita até a apresentação, isso não
compromete a entrega: o roteiro de apresentação prevê a demonstração
rodando localmente (`localhost`), o que é plenamente aceito pelo
enunciado do projeto.
