import { formatDate, formatGrades } from '../utils/formatters.js'

export default function StudentCards({ students }) {
  return (
    <div className="student-cards">
      {students.map((student) => (
        <article className="student-card" key={student.id}>
          <div className="student-card-header">
            <div>
              <h3>{student.name}</h3>
              <p>{student.email}</p>
            </div>

            <span className={student.average >= 7 ? 'grade approved' : 'grade failed'}>
              {student.average.toFixed(1)}
            </span>
          </div>

          <dl className="student-details">
            <div>
              <dt>Turma</dt>
              <dd>{student.className}</dd>
            </div>
            <div>
              <dt>Matrícula</dt>
              <dd>{student.enrollment}</dd>
            </div>
            <div>
              <dt>Data</dt>
              <dd>{formatDate(student.enrollmentDate)}</dd>
            </div>
            <div>
              <dt>Notas</dt>
              <dd>{formatGrades(student.grades)}</dd>
            </div>
          </dl>
        </article>
      ))}
    </div>
  )
}
