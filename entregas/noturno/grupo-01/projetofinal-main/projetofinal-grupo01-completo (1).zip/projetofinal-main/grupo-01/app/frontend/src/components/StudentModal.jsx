export default function StudentModal({ classes, onClose }) {
  function handleSubmit(event) {
    event.preventDefault()
    alert('Cadastro visual apenas para o protótipo. A versão final do projeto pode manter somente consulta.')
  }

  return (
    <div className="modal-backdrop" role="presentation">
      <section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <div className="modal-header">
          <h2 id="modal-title">Novo aluno</h2>
          <button type="button" className="ghost-button dark" onClick={onClose}>
            Cancelar
          </button>
        </div>

        <form className="student-form" onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="newName">Nome completo</label>
            <input id="newName" type="text" placeholder="Nome completo" />
          </div>

          <div className="field">
            <label htmlFor="newEmail">E-mail</label>
            <input id="newEmail" type="email" placeholder="email@iteamrr.edu.br" />
          </div>

          <div className="field">
            <label htmlFor="newClass">Turma</label>
            <select id="newClass" defaultValue="">
              <option value="" disabled>Selecione a turma</option>
              {classes.map((classItem) => (
                <option key={classItem.id} value={classItem.id}>
                  {classItem.name}
                </option>
              ))}
            </select>
          </div>

          <div className="form-grid">
            <div className="field">
              <label htmlFor="newEnrollment">Matrícula</label>
              <input id="newEnrollment" type="text" placeholder="2026010" />
            </div>

            <div className="field">
              <label htmlFor="newDate">Data da matrícula</label>
              <input id="newDate" type="date" />
            </div>
          </div>

          <h3 className="form-subtitle">Notas por disciplina</h3>

          <div className="form-grid three">
            <div className="field">
              <label htmlFor="math">Matemática</label>
              <input id="math" type="number" step="0.1" min="0" max="10" />
            </div>

            <div className="field">
              <label htmlFor="portuguese">Português</label>
              <input id="portuguese" type="number" step="0.1" min="0" max="10" />
            </div>

            <div className="field">
              <label htmlFor="science">Ciências</label>
              <input id="science" type="number" step="0.1" min="0" max="10" />
            </div>
          </div>

          <div className="modal-actions">
            <button type="button" className="secondary-button" onClick={onClose}>
              Cancelar
            </button>

            <button type="submit" className="primary-button">
              Salvar aluno
            </button>
          </div>
        </form>
      </section>
    </div>
  )
}
