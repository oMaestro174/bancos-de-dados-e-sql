# Backend — Consulta de Alunos (escola_db)

API simples em Node.js + Express que conecta no MySQL (`escola_db`) e
expõe, como rotas HTTP, as mesmas consultas do arquivo `../../sql/consultas.sql`.

## Pré-requisitos

- Node.js 18+ instalado
- MySQL instalado e rodando (local ou em um serviço como Railway/Clever Cloud)

## Passo a passo

1. Criar o banco e as tabelas (se ainda não usou a base oficial da disciplina):
   ```bash
   mysql -u root -p < ../../sql/schema.sql
   ```

2. Instalar as dependências:
   ```bash
   npm install
   ```

3. Configurar as variáveis de ambiente:
   ```bash
   cp .env.example .env
   # edite o .env com usuário/senha do seu MySQL
   ```

4. Rodar a API:
   ```bash
   npm start
   ```

   A API sobe em `http://localhost:3000`.

## Rotas disponíveis

| Rota                                  | O que faz                                              |
|----------------------------------------|---------------------------------------------------------|
| `GET /api/health`                      | Testa se a API está no ar                                |
| `GET /api/alunos`                      | Lista todos os alunos com turma, notas e média          |
| `GET /api/alunos?turma=BD-01`          | Filtra alunos por turma                                  |
| `GET /api/alunos?nome=Adriana`         | Busca alunos pelo nome (parcial)                         |
| `GET /api/turmas/media`                | Média geral de notas por turma (GROUP BY)                |
| `GET /api/alunos/acima-media`          | Alunos com média acima da média geral da escola (subquery) |
| `GET /api/matriculas/:id`              | Busca por número de matrícula (opcional)                 |
| `GET /api/alunos/email/:email`         | Busca por e-mail do aluno (opcional)                     |

Exemplo rápido de teste, com o servidor rodando:

```bash
curl http://localhost:3000/api/alunos
curl "http://localhost:3000/api/alunos?turma=BD-01"
curl "http://localhost:3000/api/alunos?nome=Adriana"
```

## Sobre a integração com o front-end

O front-end (`../frontend`) já funciona sozinho com dados de exemplo
(`src/data/mockData.js`), para garantir uma demonstração visual estável na
apresentação. Este backend existe para comprovar, na prática, a conexão
real com o banco `escola_db` e as consultas SQL exigidas pelo projeto —
é o que será demonstrado no bloco "Banco de dados, DER e SQL" da
apresentação (dia 07/07). Times que quiserem ir além podem conectar o
front-end a esta API trocando o import de `mockData.js` por chamadas
`fetch` para essas rotas.
