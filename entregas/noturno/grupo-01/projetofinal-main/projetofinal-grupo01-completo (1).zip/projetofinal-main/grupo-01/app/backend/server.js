// =========================================================================
// API - Consulta de Alunos (escola_db)
// Grupo 01 - Projeto Integrador de Banco de Dados e SQL
//
// Cada rota abaixo corresponde a uma consulta do arquivo sql/consultas.sql.
// O objetivo é mostrar, na prática, a mesma lógica SQL exigida pelo
// enunciado do projeto, servida como uma API que uma aplicação web
// (React, no nosso caso) poderia consumir.
// =========================================================================

require('dotenv').config()
const express = require('express')
const cors = require('cors')
const pool = require('./db')

const app = express()
app.use(cors())
app.use(express.json())

const PORT = process.env.PORT || 3000

// Rota de teste rápida, só para confirmar que a API está no ar
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', mensagem: 'API escola_db funcionando' })
})

// -------------------------------------------------------------------------
// 1. Listar alunos com turma, notas e média (consulta 1 do consultas.sql)
//    Aceita filtros opcionais via query string:
//      ?turma=BD-01   -> filtra por turma (consulta 2)
//      ?nome=Adriana  -> busca por nome (consulta 3)
// -------------------------------------------------------------------------
app.get('/api/alunos', async (req, res) => {
  const { turma, nome } = req.query

  let sql = `
    SELECT
      a.id_aluno,
      a.nome        AS nome_aluno,
      a.email,
      t.nome_turma,
      m.id_matricula,
      m.data_matricula,
      m.status,
      n.nota1,
      n.nota2,
      n.nota3,
      n.media
    FROM alunos a
    JOIN matriculas m ON a.id_aluno = m.id_aluno
    JOIN turmas t ON m.id_turma = t.id_turma
    JOIN notas n ON m.id_matricula = n.id_matricula
    WHERE 1 = 1
  `
  const params = []

  if (turma) {
    sql += ' AND t.nome_turma = ?'
    params.push(turma)
  }

  if (nome) {
    sql += ' AND a.nome LIKE ?'
    params.push(`%${nome}%`)
  }

  sql += ' ORDER BY a.nome'

  try {
    const [rows] = await pool.query(sql, params)
    res.json(rows)
  } catch (err) {
    console.error(err)
    res.status(500).json({ erro: 'Erro ao consultar alunos' })
  }
})

// -------------------------------------------------------------------------
// 2. Média de notas por turma (consulta 4 - GROUP BY)
// -------------------------------------------------------------------------
app.get('/api/turmas/media', async (req, res) => {
  const sql = `
    SELECT
      t.nome_turma,
      c.nome AS nome_curso,
      ROUND(AVG(n.media), 2) AS media_geral_da_turma,
      COUNT(m.id_matricula) AS total_alunos
    FROM turmas t
    JOIN cursos c ON t.id_curso = c.id_curso
    JOIN matriculas m ON t.id_turma = m.id_turma
    JOIN notas n ON m.id_matricula = n.id_matricula
    GROUP BY t.id_turma, t.nome_turma, c.nome
  `

  try {
    const [rows] = await pool.query(sql)
    res.json(rows)
  } catch (err) {
    console.error(err)
    res.status(500).json({ erro: 'Erro ao consultar médias por turma' })
  }
})

// -------------------------------------------------------------------------
// 3. Alunos com média acima da média geral da escola (consulta 5 - subquery)
// -------------------------------------------------------------------------
app.get('/api/alunos/acima-media', async (req, res) => {
  const sql = `
    SELECT
      a.nome AS nome_aluno,
      n.media AS media_aluno
    FROM alunos a
    JOIN matriculas m ON a.id_aluno = m.id_aluno
    JOIN notas n ON m.id_matricula = n.id_matricula
    WHERE n.media > (SELECT AVG(media) FROM notas)
    ORDER BY n.media DESC
  `

  try {
    const [rows] = await pool.query(sql)
    res.json(rows)
  } catch (err) {
    console.error(err)
    res.status(500).json({ erro: 'Erro ao consultar alunos acima da média' })
  }
})

// -------------------------------------------------------------------------
// Opcional 1: Busca por número de matrícula
// -------------------------------------------------------------------------
app.get('/api/matriculas/:id', async (req, res) => {
  const sql = `
    SELECT
      m.id_matricula,
      a.nome AS nome_aluno,
      t.nome_turma,
      c.nome AS nome_curso,
      m.data_matricula,
      m.status
    FROM matriculas m
    JOIN alunos a ON m.id_aluno = a.id_aluno
    JOIN turmas t ON m.id_turma = t.id_turma
    JOIN cursos c ON t.id_curso = c.id_curso
    WHERE m.id_matricula = ?
  `

  try {
    const [rows] = await pool.query(sql, [req.params.id])
    if (rows.length === 0) {
      return res.status(404).json({ erro: 'Matrícula não encontrada' })
    }
    res.json(rows[0])
  } catch (err) {
    console.error(err)
    res.status(500).json({ erro: 'Erro ao consultar matrícula' })
  }
})

// -------------------------------------------------------------------------
// Opcional 2: Busca por e-mail do aluno
// -------------------------------------------------------------------------
app.get('/api/alunos/email/:email', async (req, res) => {
  const sql = `
    SELECT
      a.nome AS nome_aluno,
      a.email,
      t.nome_turma,
      n.nota1,
      n.nota2,
      n.nota3,
      n.media,
      m.status
    FROM alunos a
    JOIN matriculas m ON a.id_aluno = m.id_aluno
    JOIN turmas t ON m.id_turma = t.id_turma
    JOIN notas n ON m.id_matricula = n.id_matricula
    WHERE a.email = ?
  `

  try {
    const [rows] = await pool.query(sql, [req.params.email])
    if (rows.length === 0) {
      return res.status(404).json({ erro: 'Aluno não encontrado' })
    }
    res.json(rows[0])
  } catch (err) {
    console.error(err)
    res.status(500).json({ erro: 'Erro ao consultar aluno por e-mail' })
  }
})

app.listen(PORT, () => {
  console.log(`API rodando em http://localhost:${PORT}`)
})
