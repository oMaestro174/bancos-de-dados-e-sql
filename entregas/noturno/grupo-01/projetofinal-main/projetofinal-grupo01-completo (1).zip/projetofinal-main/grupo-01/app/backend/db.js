// Conexão com o banco escola_db (MySQL)
// As credenciais vêm do arquivo .env (veja .env.example)

require('dotenv').config()
const mysql = require('mysql2/promise')

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'escola_db',
  waitForConnections: true,
  connectionLimit: 10,
})

module.exports = pool
