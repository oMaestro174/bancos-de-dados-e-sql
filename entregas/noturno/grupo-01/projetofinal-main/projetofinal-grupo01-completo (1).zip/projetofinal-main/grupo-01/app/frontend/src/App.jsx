import { useState } from 'react'
import Header from './components/Header.jsx'
import LoginPage from './components/LoginPage.jsx'
import StudentsPage from './components/StudentsPage.jsx'
import ClassesPage from './components/ClassesPage.jsx'
import StudentModal from './components/StudentModal.jsx'
import { students, classes } from './data/mockData.js'

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [activePage, setActivePage] = useState('alunos')
  const [isModalOpen, setIsModalOpen] = useState(false)

  function handleLogin() {
    setIsAuthenticated(true)
  }

  function handleLogout() {
    setIsAuthenticated(false)
    setActivePage('alunos')
    setIsModalOpen(false)
  }

  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />
  }

  return (
    <div className="app-shell">
      <Header
        activePage={activePage}
        onChangePage={setActivePage}
        onLogout={handleLogout}
      />

      <main className="main-content">
        {activePage === 'alunos' && (
          <StudentsPage
            students={students}
            classes={classes}
            onOpenNewStudent={() => setIsModalOpen(true)}
          />
        )}

        {activePage === 'turmas' && (
          <ClassesPage classes={classes} students={students} />
        )}
      </main>

      {isModalOpen && (
        <StudentModal
          classes={classes}
          onClose={() => setIsModalOpen(false)}
        />
      )}
    </div>
  )
}
