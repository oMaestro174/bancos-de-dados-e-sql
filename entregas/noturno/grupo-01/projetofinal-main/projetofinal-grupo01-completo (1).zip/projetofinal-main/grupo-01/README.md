# Grupo 01 — Consulta de Alunos (escola_db)

Projeto integrador da disciplina de Banco de Dados e SQL: aplicação web
para consulta de dados acadêmicos (aluno, e-mail, turma, matrícula,
notas e média), com filtro por turma e busca por nome.

## Estrutura desta pasta

```
grupo-01/
├── app/
│   ├── frontend/   -> Interface em React + Vite (já funcional, com dados de exemplo)
│   └── backend/    -> API em Node.js + Express, conectada ao MySQL (escola_db)
├── sql/
│   ├── consultas.sql  -> consultas SQL exigidas pelo projeto (JOINs, filtros, GROUP BY, subquery)
│   └── schema.sql     -> criação do banco escola_db + dados de exemplo
├── der/
│   └── modelorelacional.png -> Diagrama Entidade-Relacionamento
├── docs/
│   ├── integrantes-e-funcoes.md -> equipe (9 pessoas) e divisão de responsabilidades
│   └── roteiro-apresentacao.md  -> roteiro para a apresentação de 07/07
└── infra/
    └── publicacao.md -> como rodar o projeto e sugestão de publicação online
```

## Como rodar rapidamente

1. Banco de dados: `mysql -u root -p < sql/schema.sql`
2. Backend: `cd app/backend && npm install && cp .env.example .env && npm start`
3. Frontend: `cd app/frontend && npm install && npm run dev`

Detalhes completos em `infra/publicacao.md` e em `app/backend/README.md`.

## Requisitos do projeto atendidos

- [x] Nome, e-mail, turma, data de matrícula, notas e média exibidos na aplicação
- [x] Filtro por turma
- [x] Busca por nome do aluno
- [x] Opcional: busca por matrícula
- [x] Opcional: busca por e-mail
- [x] DER da base utilizada
- [x] Script SQL (criação + consultas)
- [x] Documento de integrantes e funções
- [x] Explicação sobre execução/publicação da aplicação
