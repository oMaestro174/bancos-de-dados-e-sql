# Integrantes e Divisão de Funções — Grupo 01

Equipe com 9 integrantes, dividida em 3 frentes de trabalho, conforme
pedido no enunciado do projeto (Desenvolvimento, Banco de Dados e
Infraestrutura). Substitua `[Nome do integrante]` pelos nomes reais da
equipe antes da entrega.

## Frente 1 — Desenvolvimento (aplicação, interface, integração)

Responsável pelo front-end React (`app/frontend`): telas de login, listagem
de alunos, filtros, busca por nome, cadastro/edição e tela de turmas.

| Integrante             | Responsabilidade principal                                   |
|-------------------------|----------------------------------------------------------------|
| [Nome do integrante 1] | Telas e componentes (Header, StudentsPage, ClassesPage)        |
| [Nome do integrante 2] | Filtros, busca por nome e modal de aluno (FiltersBar, StudentModal) |
| [Nome do integrante 3] | Estilo visual, responsividade e organização do CSS (App.css, global.css) |

## Frente 2 — Banco de Dados (DER, modelagem, SQL)

Responsável pela modelagem relacional, pelo script de criação do banco
(`sql/schema.sql`) e pelas consultas (`sql/consultas.sql`).

| Integrante             | Responsabilidade principal                                    |
|-------------------------|-----------------------------------------------------------------|
| [Nome do integrante 4] | DER e modelagem das tabelas (alunos, turmas, cursos)            |
| [Nome do integrante 5] | Script de criação e carga de dados (`sql/schema.sql`)           |
| [Nome do integrante 6] | Consultas SQL: JOINs, filtros, GROUP BY e subconsulta (`sql/consultas.sql`) |

## Frente 3 — Infraestrutura (ambiente, backend, publicação)

Responsável por deixar o projeto executável de ponta a ponta: subir o
banco, rodar a API (`app/backend`) e documentar a publicação.

| Integrante             | Responsabilidade principal                                    |
|-------------------------|-----------------------------------------------------------------|
| [Nome do integrante 7] | Configuração do MySQL local e execução do `schema.sql`          |
| [Nome do integrante 8] | API em Node/Express (`app/backend`) conectando ao `escola_db`   |
| [Nome do integrante 9] | Ambiente de execução e documento de publicação (`infra/publicacao.md`) |

## Como o trabalho foi dividido na prática

- O front-end (React + Vite) roda de forma independente, com dados de
  exemplo, garantindo uma demonstração visual estável.
- O banco de dados e o backend comprovam a parte de SQL e modelagem
  exigida pela disciplina (JOINs, filtros, GROUP BY e subconsulta).
- A frente de infraestrutura garante que qualquer pessoa da equipe (ou o
  professor) consiga rodar o projeto localmente seguindo o passo a passo
  descrito em `infra/publicacao.md` e em `app/backend/README.md`.

## Apresentação (07/07)

A divisão de falas na apresentação segue a mesma lógica das 3 frentes —
detalhes de tempo e conteúdo estão em `docs/roteiro-apresentacao.md`.
