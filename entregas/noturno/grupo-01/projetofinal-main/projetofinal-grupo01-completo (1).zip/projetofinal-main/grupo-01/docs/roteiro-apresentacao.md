# Roteiro de Apresentação — Grupo 01 (07/07, terça-feira)

Tempo total: até 15 minutos, seguindo a sugestão de divisão do enunciado.

## 1. Problema e proposta da solução — 3 min
*(Frente Desenvolvimento)*

- Contexto: escola precisa consultar dados acadêmicos (aluno, e-mail,
  turma, matrícula, notas, média) de forma rápida e centralizada.
- Proposta: aplicação web com listagem de alunos, filtro por turma e
  busca por nome, apoiada em um banco relacional (`escola_db`).

## 2. Demonstração da aplicação — 4 min
*(Frente Desenvolvimento)*

- Login na aplicação.
- Tela de alunos: nome, e-mail, turma, data de matrícula, notas e média.
- Filtrar por turma.
- Pesquisar por nome do aluno.
- Tela de turmas (visão agrupada).

## 3. Banco de dados, DER e SQL — 4 min
*(Frente Banco de Dados)*

- Mostrar o DER (`der/modelorelacional.png`): tabelas `alunos`, `cursos`,
  `turmas`, `matriculas`, `notas` e seus relacionamentos.
- Rodar ao vivo (ou mostrar prints) das consultas de `sql/consultas.sql`:
  1. JOIN completo (aluno + turma + notas).
  2. Filtro por turma (`WHERE t.nome_turma = 'BD-01'`).
  3. Busca por nome (`LIKE`).
  4. Média por turma (`GROUP BY`).
  5. Subconsulta: alunos acima da média geral da escola.
  6. Opcionais: busca por matrícula e por e-mail.

## 4. Infraestrutura e publicação — 2 min
*(Frente Infraestrutura)*

- Como o projeto é executado: MySQL (`sql/schema.sql`) + API em
  Node/Express (`app/backend`) + front-end em React/Vite (`app/frontend`).
- Mostrar a API respondendo (ex.: `GET /api/alunos?turma=BD-01`).
- Se houver publicação online, mostrar o link; caso contrário, explicar
  que a demonstração é local e por quê essa foi a escolha do grupo.

## 5. Equipe e responsabilidades — 2 min
*(Todos)*

- Apresentar rapidamente os 9 integrantes e as 3 frentes de trabalho
  (ver `docs/integrantes-e-funcoes.md`).
- Encerrar reforçando o que cada frente entregou.

---

**Dica geral:** treinar a transição entre as frentes (2→3→4) para não
perder tempo — quem for demonstrar a aplicação já deixa a tela do banco
ou do terminal aberta para a pessoa seguinte continuar sem pausas.
