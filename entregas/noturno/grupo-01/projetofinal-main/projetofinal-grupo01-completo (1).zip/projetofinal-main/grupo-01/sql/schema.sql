-- =========================================================================
-- SCRIPT DE CRIAÇÃO DO BANCO: escola_db
-- ARQUIVO: sql/schema.sql
-- Grupo 01 — Projeto Integrador Banco de Dados e SQL
--
-- Este arquivo cria a estrutura (DER) e popula a base com dados de
-- exemplo, para que o grupo consiga rodar o backend e o script
-- sql/consultas.sql localmente, mesmo sem a base oficial da disciplina
-- (base/ do repositório principal).
--
-- Como usar (MySQL):
--   mysql -u root -p < schema.sql
-- ou dentro do cliente MySQL:
--   SOURCE schema.sql;
-- =========================================================================

CREATE DATABASE IF NOT EXISTS escola_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE escola_db;

-- Recriar do zero (útil em ambiente de desenvolvimento/testes)
DROP TABLE IF EXISTS notas;
DROP TABLE IF EXISTS matriculas;
DROP TABLE IF EXISTS turmas;
DROP TABLE IF EXISTS cursos;
DROP TABLE IF EXISTS alunos;

-- -------------------------------------------------------------------------
-- Tabela: cursos
-- -------------------------------------------------------------------------
CREATE TABLE cursos (
  id_curso    INT AUTO_INCREMENT PRIMARY KEY,
  nome        VARCHAR(100) NOT NULL
);

-- -------------------------------------------------------------------------
-- Tabela: turmas
-- -------------------------------------------------------------------------
CREATE TABLE turmas (
  id_turma    INT AUTO_INCREMENT PRIMARY KEY,
  nome_turma  VARCHAR(50) NOT NULL,
  id_curso    INT NOT NULL,
  CONSTRAINT fk_turmas_curso FOREIGN KEY (id_curso) REFERENCES cursos(id_curso)
);

-- -------------------------------------------------------------------------
-- Tabela: alunos
-- -------------------------------------------------------------------------
CREATE TABLE alunos (
  id_aluno    INT AUTO_INCREMENT PRIMARY KEY,
  nome        VARCHAR(150) NOT NULL,
  email       VARCHAR(150) NOT NULL UNIQUE,
  cidade      VARCHAR(100)
);

-- -------------------------------------------------------------------------
-- Tabela: matriculas (liga aluno <-> turma)
-- -------------------------------------------------------------------------
CREATE TABLE matriculas (
  id_matricula    INT AUTO_INCREMENT PRIMARY KEY,
  id_aluno        INT NOT NULL,
  id_turma        INT NOT NULL,
  data_matricula  DATE NOT NULL,
  status          VARCHAR(20) NOT NULL DEFAULT 'ativo',
  CONSTRAINT fk_matriculas_aluno FOREIGN KEY (id_aluno) REFERENCES alunos(id_aluno),
  CONSTRAINT fk_matriculas_turma FOREIGN KEY (id_turma) REFERENCES turmas(id_turma)
);

-- -------------------------------------------------------------------------
-- Tabela: notas (1 para 1 com matricula)
-- -------------------------------------------------------------------------
CREATE TABLE notas (
  id_matricula  INT PRIMARY KEY,
  nota1         DECIMAL(4,2) NOT NULL,
  nota2         DECIMAL(4,2) NOT NULL,
  nota3         DECIMAL(4,2) NOT NULL,
  media         DECIMAL(4,2) NOT NULL,
  CONSTRAINT fk_notas_matricula FOREIGN KEY (id_matricula) REFERENCES matriculas(id_matricula)
);

-- =========================================================================
-- DADOS DE EXEMPLO
-- =========================================================================

INSERT INTO cursos (id_curso, nome) VALUES
  (1, 'Desenvolvimento de Sistemas'),
  (2, 'Banco de Dados');

INSERT INTO turmas (id_turma, nome_turma, id_curso) VALUES
  (1, 'BD-01', 2),
  (2, 'BD-02', 2),
  (3, 'DS-01', 1);

-- id_aluno é sequencial de 1 a 12 (mesma ordem usada nas matrículas abaixo)
INSERT INTO alunos (id_aluno, nome, email, cidade) VALUES
  (1,  'Ana Beatriz Souza',        'ana.souza@iteamrr.edu.br',        'Boa Vista'),
  (2,  'Bruno Carvalho Lima',      'bruno.lima@iteamrr.edu.br',       'Boa Vista'),
  (3,  'Carla Mendes Ferreira',    'carla.ferreira@iteamrr.edu.br',   'Boa Vista'),
  (4,  'Daniel Ribeiro Alves',     'daniel.alves@iteamrr.edu.br',     'Rorainópolis'),
  (5,  'Eduarda Nascimento',       'eduarda.nascimento@iteamrr.edu.br','Boa Vista'),
  (6,  'Felipe Martins Rocha',     'felipe.rocha@iteamrr.edu.br',     'Caracaraí'),
  (7,  'Gabriela Costa Lima',      'gabriela.lima@iteamrr.edu.br',    'Boa Vista'),
  (8,  'Henrique Almeida',         'henrique.almeida@iteamrr.edu.br', 'Boa Vista'),
  (9,  'Isadora Pereira Gomes',    'isadora.gomes@iteamrr.edu.br',    'Mucajaí'),
  (10, 'Adriana Fontes Xavier',    'adriana.xavier@iteamrr.edu.br',   'Boa Vista'),
  (11, 'Alan Ribeiro Souza',       'alan.ribeiro2@email.com',         'Boa Vista'),
  (12, 'Juliana Prado Martins',    'juliana.martins@iteamrr.edu.br',  'Pacaraima');

-- id_matricula também sequencial de 1 a 12, na mesma ordem dos alunos acima
INSERT INTO matriculas (id_matricula, id_aluno, id_turma, data_matricula, status) VALUES
  (1,  1,  1, '2026-02-03', 'ativo'),
  (2,  2,  1, '2026-02-03', 'ativo'),
  (3,  3,  2, '2026-02-04', 'ativo'),
  (4,  4,  2, '2026-02-04', 'ativo'),
  (5,  5,  3, '2026-02-05', 'ativo'),
  (6,  6,  3, '2026-02-05', 'ativo'),
  (7,  7,  1, '2026-02-06', 'ativo'),
  (8,  8,  2, '2026-02-06', 'trancado'),
  (9,  9,  3, '2026-02-07', 'ativo'),
  (10, 10, 1, '2026-02-07', 'ativo'),
  (11, 11, 2, '2026-02-08', 'ativo'),
  (12, 12, 3, '2026-02-08', 'ativo');

INSERT INTO notas (id_matricula, nota1, nota2, nota3, media) VALUES
  (1,  8.5, 7.0, 9.0, 8.17),
  (2,  5.0, 6.5, 4.0, 5.17),
  (3,  9.5, 8.0, 9.0, 8.83),
  (4,  6.0, 7.5, 5.5, 6.33),
  (5,  4.5, 5.0, 6.0, 5.17),
  (6,  7.5, 8.0, 7.0, 7.50),
  (7,  8.0, 8.5, 7.5, 8.00),
  (8,  6.0, 5.0, 6.5, 5.83),
  (9,  9.0, 9.5, 8.5, 9.00),
  (10, 9.0, 8.5, 9.5, 9.00),
  (11, 6.5, 7.0, 6.0, 6.50),
  (12, 8.0, 7.0, 8.5, 7.83);

-- Fim do script. Depois de rodar este arquivo, sql/consultas.sql já pode
-- ser executado normalmente (a query 2 usa 'BD-01', a 3 usa 'Adriana' e a
-- opcional 2 usa o e-mail 'alan.ribeiro2@email.com' — todos existem aqui).
